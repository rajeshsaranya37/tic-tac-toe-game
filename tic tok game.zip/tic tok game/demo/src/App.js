
import './App.css';
import TicTakToe from './Components/TicTakToe/TicTakToe';

function App() {
  return (
    <div>
      <TicTakToe/>
    </div>
  );
}

export default App;
